# Tenant / App
# TENANT_ID=4bd7b06c-d824-44d5-92c7-a5efb29af1d7
# CLIENT_ID=b163abc9-33a5-4dce-ad85-8216b1d6eaf1
# CLIENT_SECRET=Uns8Q~ZRu3~GuTWN5IcSvCs7NiM1X1BwY71tOdqj

# Account
dev_remove_massey@GPSExperimentationSandbox.onmicrosoft.com
Koba781085_25

# LOGIN Method
$s = irm -Method POST http://localhost:8080/auth/device-code/start
$s.message        # shows the code + URL

irm -Method POST "http://localhost:8080/auth/device-code/poll?device_code=$($s.device_code)"