import os
from typing import Optional, Dict, Any
from msal import (
    PublicClientApplication,
    ConfidentialClientApplication,
    SerializableTokenCache,
)
from .config import settings

def _load_cache() -> SerializableTokenCache:
    cache = SerializableTokenCache()
    try:
        if os.path.exists(settings.token_cache_path):
            with open(settings.token_cache_path, "r") as f:
                cache.deserialize(f.read())
    except Exception:
        pass
    return cache

def _save_cache(cache: SerializableTokenCache):
    if cache.has_state_changed:
        os.makedirs(os.path.dirname(settings.token_cache_path), exist_ok=True)
        with open(settings.token_cache_path, "w") as f:
            f.write(cache.serialize())

def get_public_app(cache: Optional[SerializableTokenCache] = None) -> PublicClientApplication:
    cache = cache or _load_cache()
    return PublicClientApplication(
        client_id=settings.client_id,
        authority=f"https://login.microsoftonline.com/{settings.tenant_id}",
        token_cache=cache,
    )

def get_confidential_app(cache: Optional[SerializableTokenCache] = None) -> ConfidentialClientApplication:
    cache = cache or _load_cache()
    return ConfidentialClientApplication(
        client_id=settings.client_id,
        client_credential=settings.client_secret,
        authority=f"https://login.microsoftonline.com/{settings.tenant_id}",
        token_cache=cache,
    )

def start_device_flow() -> Dict[str, Any]:
    cache = _load_cache()
    app = get_public_app(cache)
    # ✅ plain delegated scopes (include offline_access)
    scopes = list(settings.graph_scope_delegated)
    flow = app.initiate_device_flow(scopes=scopes)
    if "user_code" not in flow:
        raise RuntimeError("Failed to create device flow.")
    _save_cache(cache)
    return {
        "verification_uri": flow.get("verification_uri"),
        "user_code": flow.get("user_code"),
        "message": flow.get("message"),
        "expires_in": flow.get("expires_in"),
        "device_code": flow.get("device_code"),
    }

def poll_device_flow(device_code: str) -> Dict[str, Any]:
    cache = _load_cache()
    app = get_public_app(cache)
    result = app.acquire_token_by_device_flow({"device_code": device_code})
    if "access_token" in result:
        _save_cache(cache)
        return {"ok": True, "expires_in": result.get("expires_in", 0)}
    return {"ok": False, "error": result.get("error_description", "unknown")}

def get_delegated_token() -> Optional[str]:
    cache = _load_cache()
    app = get_public_app(cache)
    accounts = app.get_accounts(username=settings.preferred_username) or app.get_accounts()
    if accounts:
        result = app.acquire_token_silent(
            scopes=list(settings.graph_scope_delegated),
            account=accounts[0],
        )
        if result and "access_token" in result:
            _save_cache(cache)
            return result["access_token"]
    return None

def get_app_token() -> str:
    cache = _load_cache()
    app = get_confidential_app(cache)
    result = app.acquire_token_for_client(scopes=settings.graph_scope_application)
    if "access_token" in result:
        _save_cache(cache)
        return result["access_token"]
    raise RuntimeError(f"Failed to get app token: {result.get('error_description') or result}")
