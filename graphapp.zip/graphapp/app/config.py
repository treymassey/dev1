from pydantic import BaseModel
from dotenv import load_dotenv
import os

# Load variables from .env (compose will also inject them)
load_dotenv()

class Settings(BaseModel):
    # Required IDs/secret (provided by Entra ID app registration)
    tenant_id: str = os.getenv("TENANT_ID", "")
    client_id: str = os.getenv("CLIENT_ID", "")
    client_secret: str = os.getenv("CLIENT_SECRET", "")

    # Optional hints / paths
    preferred_username: str = os.getenv("PREFERRED_USERNAME", "")
    token_cache_path: str = os.getenv("TOKEN_CACHE_PATH", "/data/token-cache.json")
    port: int = int(os.getenv("PORT", "8080"))
    default_tz: str = os.getenv("DEFAULT_TZ", "America/Chicago")

    # Microsoft Graph constants
    graph_resource: str = "https://graph.microsoft.com"  # resource root
    graph_api_base: str = "https://graph.microsoft.com/v1.0"

    # Delegated scopes MUST be plain (no resource prefix) and may include 'offline_access'
    graph_scope_delegated: list[str] = [
        "User.Read",
        "Chat.ReadWrite",
        "ChannelMessage.Send",
        "Mail.Send",
        "Calendars.ReadWrite",
        "Group.Read.All",
        "Group.ReadWrite.All",
        "OnlineMeetings.ReadWrite",
    ]

    # Application flow uses /.default (maps to whatever app perms received admin consent)
    graph_scope_application: list[str] = [f"{graph_resource}/.default"]

settings = Settings()
