from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

from .auth import (
    start_device_flow,
    poll_device_flow,
    get_delegated_token,
    get_app_token,
)
from .msgraph import GraphClient
from .config import settings

api = FastAPI(title="Graph Test App", version="1.0")


# ---------- Auth endpoints (Delegated) ----------
class StartFlowResponse(BaseModel):
    verification_uri: str
    user_code: str
    message: str
    expires_in: int
    device_code: str


@api.post("/auth/device-code/start", response_model=StartFlowResponse)
async def auth_start():
    return start_device_flow()


@api.post("/auth/device-code/poll")
async def auth_poll(device_code: str):
    return poll_device_flow(device_code)


# ---------- Internal helper ----------
async def _client(mode: str) -> GraphClient:
    if mode == "delegated":
        tok = get_delegated_token()
        if not tok:
            raise HTTPException(
                401, "No delegated token. Start device flow at /auth/device-code/start."
            )
    elif mode == "application":
        tok = get_app_token()
    else:
        raise HTTPException(400, "mode must be 'delegated' or 'application'")
    return GraphClient(tok)


# ---------- Me ----------
@api.get("/me")
async def me(mode: str = "delegated"):
    # /me is only meaningful in delegated mode
    if mode == "application":
        raise HTTPException(400, "/me requires delegated auth; use mode=delegated.")
    c = await _client(mode)
    try:
        return await c.me()
    finally:
        await c.close()


# ---------- Email ----------
class EmailBody(BaseModel):
    to: List[str]
    subject: str
    html: str


@api.post("/mail/send")
async def mail_send(body: EmailBody, mode: str = "delegated"):
    c = await _client(mode)
    try:
        return await c.send_mail_me(body.subject, body.html, body.to)
    finally:
        await c.close()


# ---------- Meetings ----------
class MeetingRequest(BaseModel):
    subject: str
    start_iso: str  # e.g., "2025-09-09T16:00:00-05:00"
    end_iso: str
    attendees: List[str] = []


@api.post("/meetings/schedule")
async def meetings_schedule(req: MeetingRequest, mode: str = "delegated"):
    c = await _client(mode)
    try:
        return await c.schedule_meeting(
            req.subject, req.start_iso, req.end_iso, req.attendees
        )
    finally:
        await c.close()


@api.get("/meetings/list")
async def meetings_list(start_iso: str, end_iso: str, mode: str = "delegated"):
    c = await _client(mode)
    try:
        return await c.list_my_meetings(start_iso, end_iso)
    finally:
        await c.close()


# ---------- Chats ----------
class ChatPost(BaseModel):
    text: str


@api.post("/chats/{chat_id}/post")
async def chats_post(chat_id: str, body: ChatPost, mode: str = "delegated"):
    c = await _client(mode)
    try:
        return await c.post_to_chat(chat_id, body.text)
    finally:
        await c.close()


# ---------- NEW: 1:1 Chat helper ----------
class OneToOneMessage(BaseModel):
    upn: str  # target user's UPN (email-style)
    text: str  # html/text content


@api.post("/chats/1to1/send")
async def chats_1to1_send(body: OneToOneMessage, mode: str = "delegated"):
    if mode != "delegated":
        raise HTTPException(400, "This endpoint requires mode=delegated.")
    c = await _client(mode)
    try:
        me = await c.me()
        target = await c.get_user_by_upn(body.upn)
        chat = await c.ensure_1to1_chat_between(me["id"], target["id"])
        chat_id = chat.get("id")
        if not chat_id:
            raise HTTPException(500, "Could not determine chatId.")
        msg = await c.post_to_chat(chat_id, body.text)
        return {"ok": True, "chatId": chat_id, "messageId": msg.get("id")}
    finally:
        await c.close()


# ---------- Channels (app-mode by default) ----------
class ChannelPost(BaseModel):
    team_id: str
    channel_id: str
    text: str


@api.post("/channels/post")
async def channels_post(body: ChannelPost, mode: str = "application"):
    c = await _client(mode)
    try:
        return await c.post_to_channel(body.team_id, body.channel_id, body.text)
    finally:
        await c.close()


# ---------- Lookups ----------
@api.get("/groups/search")
async def groups_search(q: str, mode: str = "application"):
    c = await _client(mode)
    try:
        return await c.search_groups(q)
    finally:
        await c.close()


@api.get("/teams/{team_id}/channels")
async def teams_channels(team_id: str, mode: str = "application"):
    c = await _client(mode)
    try:
        return await c.team_channels(team_id)
    finally:
        await c.close()
