import httpx
from typing import Optional, List
from .config import settings


class GraphClient:
    def __init__(self, token: str):
        self._token = token
        self._base = f"{settings.graph_resource}/v1.0"
        self._client = httpx.AsyncClient(timeout=30.0)

    async def close(self):
        await self._client.aclose()

    def _headers(self):
        return {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }

    # -------- Me --------
    async def me(self):
        r = await self._client.get(f"{self._base}/me", headers=self._headers())
        r.raise_for_status()
        return r.json()

    # -------- Email --------
    async def send_mail_me(self, subject: str, content_html: str, to: List[str]):
        body = {
            "message": {
                "subject": subject,
                "body": {"contentType": "HTML", "content": content_html},
                "toRecipients": [{"emailAddress": {"address": a}} for a in to],
            },
            "saveToSentItems": "true",
        }
        r = await self._client.post(
            f"{self._base}/me/sendMail", headers=self._headers(), json=body
        )
        r.raise_for_status()
        return {"ok": True}

    # -------- Meetings --------
    async def schedule_meeting(
        self, subject: str, start_iso: str, end_iso: str, attendees: List[str]
    ):
        body = {
            "subject": subject,
            "startDateTime": start_iso,
            "endDateTime": end_iso,
            "participants": {
                "organizer": {"identity": {"user": {}}},
                "attendees": [{"upn": a} for a in attendees],
            },
        }
        r = await self._client.post(
            f"{self._base}/me/onlineMeetings", headers=self._headers(), json=body
        )
        r.raise_for_status()
        return r.json()  # contains joinUrl, chatInfo, id, etc.

    async def list_my_meetings(self, start_iso: str, end_iso: str):
        r = await self._client.get(
            f"{self._base}/me/calendarView?startDateTime={start_iso}&endDateTime={end_iso}",
            headers=self._headers(),
        )
        r.raise_for_status()
        return r.json()

    # -------- Chats (generic) --------
    async def post_to_chat(self, chat_id: str, text: str):
        body = {"body": {"contentType": "html", "content": text}}
        r = await self._client.post(
            f"{self._base}/chats/{chat_id}/messages",
            headers=self._headers(),
            json=body,
        )
        r.raise_for_status()
        return r.json()

    # -------- NEW: Resolve user & ensure 1:1 chat --------
    async def get_user_by_upn(self, upn: str):
        r = await self._client.get(f"{self._base}/users/{upn}", headers=self._headers())
        r.raise_for_status()
        return r.json()

    async def ensure_1to1_chat_between(self, me_id: str, other_user_id: str):
        """
        Creates a 1:1 chat between the caller (me_id) and other_user_id if it doesn't exist.
        Returns the chat resource (expects an 'id' field).
        """
        body = {
            "chatType": "oneOnOne",
            "members": [
                {
                    "@odata.type": "#microsoft.graph.aadUserConversationMember",
                    "roles": ["owner"],
                    "user@odata.bind": f"{settings.graph_resource}/v1.0/users('{me_id}')",
                },
                {
                    "@odata.type": "#microsoft.graph.aadUserConversationMember",
                    "roles": ["owner"],
                    "user@odata.bind": f"{settings.graph_resource}/v1.0/users('{other_user_id}')",
                },
            ],
        }
        r = await self._client.post(
            f"{self._base}/chats", headers=self._headers(), json=body
        )
        # Some tenants return 409 if the chat already exists; try to parse JSON anyway
        if r.status_code not in (200, 201, 409):
            r.raise_for_status()
        try:
            return r.json()
        except Exception:
            # If the service returned no JSON on 409, surface a helpful error
            raise RuntimeError("1:1 chat may already exist but could not be resolved.")

    # -------- Channel messages --------
    async def post_to_channel(self, team_id: str, channel_id: str, text: str):
        body = {"body": {"contentType": "html", "content": text}}
        r = await self._client.post(
            f"{self._base}/teams/{team_id}/channels/{channel_id}/messages",
            headers=self._headers(),
            json=body,
        )
        r.raise_for_status()
        return r.json()

    # -------- Lookups --------
    async def search_groups(self, keyword: str):
        r = await self._client.get(
            f"{self._base}/groups?$search=\"{keyword}\"",
            headers={**self._headers(), "ConsistencyLevel": "eventual"},
        )
        r.raise_for_status()
        return r.json()

    async def team_channels(self, team_id: str):
        r = await self._client.get(
            f"{self._base}/teams/{team_id}/channels", headers=self._headers()
        )
        r.raise_for_status()
        return r.json()
